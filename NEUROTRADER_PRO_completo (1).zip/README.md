# NEUROTRADE
bot automatico
