"""
NEUROTRADER PRO — Panel de Gestión de Licencias
Aplicación independiente para crear y administrar códigos de acceso al bot.
"""
import streamlit as st
import json
import os
import random
import string
from datetime import datetime, date

st.set_page_config(
    page_title="NeuroTrader — Gestor de Licencias",
    page_icon="🔑",
    layout="wide",
    initial_sidebar_state="expanded",
)

LICENCIAS_FILE = "licencias.json"
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "jack1999@2007@")


# ─── UI ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@400;500;600;700&display=swap');

* { box-sizing: border-box; }

.stApp {
    background: radial-gradient(ellipse at 20% 50%, #0d1b2a 0%, #0a0c15 40%, #060810 100%);
    font-family: 'Rajdhani', sans-serif;
}

section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1520 0%, #0a0e1a 100%);
    border-right: 1px solid rgba(0,163,255,0.25);
}

.main-title {
    font-family: 'Orbitron', monospace;
    font-size: 2rem;
    font-weight: 900;
    background: linear-gradient(135deg, #00a3ff 0%, #00ffcc 50%, #0066ff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: 3px;
    margin-bottom: 0;
}

.lic-card {
    background: linear-gradient(145deg, #1a2035 0%, #0f1628 100%);
    border-radius: 12px;
    padding: 14px 18px;
    margin: 6px 0;
    border: 1px solid rgba(0,163,255,0.18);
    position: relative;
}
.lic-card.active  { border-color: rgba(0,255,136,0.35); }
.lic-card.expired { border-color: rgba(255,75,75,0.35);  }
.lic-card.inactive{ border-color: rgba(180,180,180,0.2); }

.code-badge {
    font-family: 'Orbitron', monospace;
    font-size: 1.05rem;
    color: #00a3ff;
    letter-spacing: 2px;
    font-weight: 700;
}
.badge-active   { color: #00ff88; }
.badge-expired  { color: #ff4b4b; }
.badge-inactive { color: #888;    }

.stat-box {
    background: linear-gradient(145deg, #1a2035, #0f1628);
    border-radius: 10px;
    padding: 16px;
    text-align: center;
    border: 1px solid rgba(0,163,255,0.2);
}
.stat-num { font-size: 2.2rem; font-weight: 700; color: #00a3ff; }
.stat-lbl { font-size: 0.78rem; color: rgba(150,180,220,0.7); letter-spacing: 2px; }

hr { border-color: rgba(0,163,255,0.15); }
</style>
""", unsafe_allow_html=True)


# ─── FUNCIONES ────────────────────────────────────────────────────────────────

def cargar_licencias() -> dict:
    if os.path.exists(LICENCIAS_FILE):
        try:
            with open(LICENCIAS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def guardar_licencias(licencias: dict) -> bool:
    try:
        with open(LICENCIAS_FILE, 'w', encoding='utf-8') as f:
            json.dump(licencias, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


def generar_codigo(longitud=12) -> str:
    partes = [
        ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
        for _ in range(3)
    ]
    return '-'.join(partes)


def estado_licencia(lic: dict) -> str:
    if not lic.get('active', True):
        return 'inactive'
    expires = lic.get('expires')
    if expires:
        try:
            if datetime.now() > datetime.fromisoformat(expires):
                return 'expired'
        except Exception:
            pass
    return 'active'


def dias_restantes(expires_str: str) -> int | None:
    if not expires_str:
        return None
    try:
        exp = datetime.fromisoformat(expires_str)
        delta = (exp - datetime.now()).days
        return delta
    except Exception:
        return None


# ─── AUTENTICACIÓN ────────────────────────────────────────────────────────────

if 'autenticado' not in st.session_state:
    st.session_state.autenticado = False

with st.sidebar:
    st.markdown('<p class="main-title">🔑 LICENCIAS</p>', unsafe_allow_html=True)
    st.markdown('<div style="color:rgba(0,163,255,0.5);font-size:0.7rem;letter-spacing:3px;margin-bottom:20px">NEUROTRADER PRO — ADMIN</div>', unsafe_allow_html=True)
    st.markdown("---")

    if not st.session_state.autenticado:
        pwd = st.text_input("Contraseña de administrador", type="password", key="admin_pwd")
        if st.button("INGRESAR", use_container_width=True, type="primary"):
            if pwd == ADMIN_PASSWORD:
                st.session_state.autenticado = True
                st.rerun()
            else:
                st.error("Contraseña incorrecta")
    else:
        st.success("Sesión activa", icon="✅")
        if st.button("CERRAR SESIÓN", use_container_width=True):
            st.session_state.autenticado = False
            st.rerun()

        st.markdown("---")
        st.markdown("**Archivo de datos:**")
        st.code(LICENCIAS_FILE, language=None)
        ruta_abs = os.path.abspath(LICENCIAS_FILE)
        st.caption(ruta_abs)

        st.markdown("---")
        st.caption("Contraseña de admin:\nVariable de entorno `ADMIN_PASSWORD`")
        st.caption(f"Valor actual: `{'(por defecto)' if not os.environ.get('ADMIN_PASSWORD') else 'configurado'}`")

# ─── CONTENIDO PRINCIPAL ──────────────────────────────────────────────────────

if not st.session_state.autenticado:
    st.markdown('<p class="main-title">🔑 NEUROTRADER PRO</p>', unsafe_allow_html=True)
    st.markdown("### Panel de Gestión de Licencias")
    st.info("Ingresa la contraseña de administrador en el panel lateral para acceder.")
    st.stop()

# Carga actual de licencias
licencias = cargar_licencias()

# ── Encabezado ─────────────────────────────────────────────────────────────
st.markdown('<p class="main-title">🔑 GESTOR DE LICENCIAS</p>', unsafe_allow_html=True)
st.markdown('<div style="color:rgba(0,163,255,0.5);font-size:0.75rem;letter-spacing:4px;margin-bottom:20px">NEUROTRADER PRO — PANEL DE ADMINISTRACIÓN</div>', unsafe_allow_html=True)

# ── Métricas ──────────────────────────────────────────────────────────────
total   = len(licencias)
activas = sum(1 for l in licencias.values() if estado_licencia(l) == 'active')
expiradas  = sum(1 for l in licencias.values() if estado_licencia(l) == 'expired')
inactivas  = sum(1 for l in licencias.values() if estado_licencia(l) == 'inactive')

c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f'<div class="stat-box"><div class="stat-num" style="color:#00a3ff">{total}</div><div class="stat-lbl">TOTAL</div></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="stat-box"><div class="stat-num" style="color:#00ff88">{activas}</div><div class="stat-lbl">ACTIVAS</div></div>', unsafe_allow_html=True)
with c3:
    st.markdown(f'<div class="stat-box"><div class="stat-num" style="color:#ff4b4b">{expiradas}</div><div class="stat-lbl">EXPIRADAS</div></div>', unsafe_allow_html=True)
with c4:
    st.markdown(f'<div class="stat-box"><div class="stat-num" style="color:#888">{inactivas}</div><div class="stat-lbl">INACTIVAS</div></div>', unsafe_allow_html=True)

st.markdown("---")

# ── Pestañas ──────────────────────────────────────────────────────────────
tab_crear, tab_lista, tab_editar = st.tabs(["➕  CREAR LICENCIA", "📋  LISTADO", "✏️  EDITAR / ELIMINAR"])

# ════════════════════════════════════════════════════════════
# TAB 1: CREAR LICENCIA
# ════════════════════════════════════════════════════════════
with tab_crear:
    st.markdown("### Nueva licencia")

    col_form, col_prev = st.columns([3, 2])

    with col_form:
        with st.form("form_crear", clear_on_submit=False):
            codigo_auto = generar_codigo()

            codigo_input = st.text_input(
                "Código de licencia",
                value=codigo_auto,
                help="Edita el código o usa el generado automáticamente",
                max_chars=30,
            )
            descripcion  = st.text_input("Descripción / nombre del cliente", placeholder="Ej: Juan Pérez — Plan mensual")
            sin_expiry   = st.checkbox("Sin fecha de vencimiento", value=True)
            fecha_exp    = None
            if not sin_expiry:
                fecha_exp = st.date_input(
                    "Fecha de vencimiento",
                    value=date.today(),
                    min_value=date.today(),
                )
            activo_default = st.checkbox("Activar inmediatamente", value=True)

            submitted = st.form_submit_button("CREAR LICENCIA", use_container_width=True, type="primary")

        if submitted:
            codigo_final = codigo_input.strip().upper()
            if not codigo_final:
                st.error("El código no puede estar vacío")
            elif codigo_final in licencias:
                st.warning(f"El código `{codigo_final}` ya existe. Usa un código diferente o edítalo en la pestaña 'Editar'.")
            else:
                licencias[codigo_final] = {
                    'active':      activo_default,
                    'descripcion': descripcion.strip(),
                    'expires':     fecha_exp.isoformat() if fecha_exp and not sin_expiry else None,
                    'creado':      datetime.now().isoformat()[:19],
                }
                if guardar_licencias(licencias):
                    st.success(f"Licencia `{codigo_final}` creada correctamente.")
                    st.balloons()
                else:
                    st.error("Error al guardar. Verifica permisos del archivo.")

    with col_prev:
        st.markdown("#### Vista previa del código")
        preview_code = st.text_input("", value=generar_codigo(), label_visibility="collapsed", key="preview_gen")
        if st.button("🔄 Generar nuevo código", use_container_width=True):
            st.rerun()
        st.markdown("---")
        st.markdown("**Formato del código:**")
        st.markdown("""
- 12 caracteres: `XXXX-XXXX-XXXX`
- Solo letras mayúsculas y números
- El cliente lo ingresa exactamente igual en el bot
        """)
        st.markdown("---")
        st.info("El cliente ingresa este código junto con su correo y contraseña de IQ Option al iniciar el bot.")


# ════════════════════════════════════════════════════════════
# TAB 2: LISTADO
# ════════════════════════════════════════════════════════════
with tab_lista:
    st.markdown("### Todas las licencias")

    # Filtros
    col_f1, col_f2, col_f3 = st.columns([2, 2, 1])
    with col_f1:
        filtro_texto = st.text_input("Buscar por código o descripción", placeholder="Escribe para filtrar…")
    with col_f2:
        filtro_estado = st.selectbox("Estado", ["Todos", "Activas", "Expiradas", "Inactivas"])
    with col_f3:
        st.markdown("")
        st.markdown("")
        if st.button("↻ Actualizar", use_container_width=True):
            licencias = cargar_licencias()
            st.rerun()

    # Aplicar filtros
    lista_filtrada = {}
    for cod, lic in licencias.items():
        est = estado_licencia(lic)
        if filtro_estado == "Activas"   and est != 'active':   continue
        if filtro_estado == "Expiradas" and est != 'expired':  continue
        if filtro_estado == "Inactivas" and est != 'inactive': continue
        if filtro_texto and filtro_texto.lower() not in cod.lower() and filtro_texto.lower() not in lic.get('descripcion','').lower():
            continue
        lista_filtrada[cod] = lic

    st.caption(f"Mostrando {len(lista_filtrada)} de {total} licencias")
    st.markdown("")

    if not lista_filtrada:
        st.info("No hay licencias que coincidan con los filtros seleccionados.")
    else:
        for cod, lic in lista_filtrada.items():
            est = estado_licencia(lic)
            badge_class = {'active': 'badge-active', 'expired': 'badge-expired', 'inactive': 'badge-inactive'}[est]
            estado_txt  = {'active': '✅ ACTIVA', 'expired': '❌ EXPIRADA', 'inactive': '⏸ INACTIVA'}[est]
            card_class  = {'active': 'active', 'expired': 'expired', 'inactive': 'inactive'}[est]

            dias = dias_restantes(lic.get('expires'))
            if dias is not None:
                if dias > 0:
                    venc_txt = f"Vence en {dias} día{'s' if dias != 1 else ''}"
                elif dias == 0:
                    venc_txt = "Vence hoy"
                else:
                    venc_txt = f"Expiró hace {abs(dias)} días"
            else:
                venc_txt = "Sin vencimiento"

            desc = lic.get('descripcion') or '—'
            creado = lic.get('creado', '')[:10]

            st.markdown(f"""
<div class="lic-card {card_class}">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
    <span class="code-badge">{cod}</span>
    <span class="{badge_class}" style="font-size:0.8rem;letter-spacing:1px">{estado_txt}</span>
  </div>
  <div style="color:rgba(180,200,240,0.85);font-size:0.9rem;margin-bottom:2px">{desc}</div>
  <div style="display:flex;gap:20px;font-size:0.75rem;color:rgba(120,150,190,0.7);margin-top:6px">
    <span>📅 Creado: {creado}</span>
    <span>⏳ {venc_txt}</span>
  </div>
</div>
""", unsafe_allow_html=True)

    # Exportar como JSON
    st.markdown("---")
    if licencias:
        json_export = json.dumps(licencias, indent=2, ensure_ascii=False)
        st.download_button(
            label="⬇️ Exportar JSON completo",
            data=json_export,
            file_name="licencias_export.json",
            mime="application/json",
        )


# ════════════════════════════════════════════════════════════
# TAB 3: EDITAR / ELIMINAR
# ════════════════════════════════════════════════════════════
with tab_editar:
    st.markdown("### Editar o eliminar licencia")

    if not licencias:
        st.info("No hay licencias registradas aún.")
    else:
        opciones = list(licencias.keys())
        cod_sel = st.selectbox("Seleccionar licencia", opciones, format_func=lambda c: f"{c}  —  {licencias[c].get('descripcion','')}")

        if cod_sel:
            lic_sel = licencias[cod_sel]
            est_actual = estado_licencia(lic_sel)
            st.markdown(f"**Estado actual:** `{est_actual.upper()}`")
            st.markdown("---")

            with st.form("form_editar"):
                nueva_desc   = st.text_input("Descripción", value=lic_sel.get('descripcion', ''))
                nuevo_activo = st.checkbox("Activa", value=lic_sel.get('active', True))

                sin_exp_edit = st.checkbox(
                    "Sin fecha de vencimiento",
                    value=lic_sel.get('expires') is None
                )
                fecha_exp_edit = None
                if not sin_exp_edit:
                    try:
                        val_ini = date.fromisoformat(lic_sel.get('expires', date.today().isoformat())[:10])
                    except Exception:
                        val_ini = date.today()
                    fecha_exp_edit = st.date_input("Nueva fecha de vencimiento", value=val_ini)

                col_save, col_del = st.columns(2)
                with col_save:
                    save = st.form_submit_button("GUARDAR CAMBIOS", use_container_width=True, type="primary")
                with col_del:
                    eliminar = st.form_submit_button("ELIMINAR LICENCIA", use_container_width=True)

            if save:
                licencias[cod_sel]['descripcion'] = nueva_desc.strip()
                licencias[cod_sel]['active']       = nuevo_activo
                licencias[cod_sel]['expires']      = (
                    fecha_exp_edit.isoformat() if fecha_exp_edit and not sin_exp_edit else None
                )
                if guardar_licencias(licencias):
                    st.success(f"Licencia `{cod_sel}` actualizada.")
                    st.rerun()
                else:
                    st.error("Error al guardar.")

            if eliminar:
                del licencias[cod_sel]
                if guardar_licencias(licencias):
                    st.warning(f"Licencia `{cod_sel}` eliminada.")
                    st.rerun()
                else:
                    st.error("Error al guardar.")
